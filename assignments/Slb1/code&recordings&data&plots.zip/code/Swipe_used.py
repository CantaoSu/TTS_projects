import os
import pysptk
import numpy as np
import pandas as pd
import librosa

audio_dir = '../recordings/'
output_dir = '../data/'
os.makedirs(output_dir, exist_ok=True)

def swipe(x, fs, hopsize, min, max, threshold =0.3 , otype='f0'):
  return pysptk.sptk.swipe(x, fs, hopsize, min, max, threshold,otype)

# Iterate through each file in the audio directory
for file_name in os.listdir(audio_dir):
    if file_name.endswith('.wav'):
        # Get the full path of the audio file
        file_path = os.path.join(audio_dir, file_name)

        # Determine fmin and fmax based on the last letter of the file name
        if file_name[-6:-4] == 'fm':
            fmin, fmax = 140, 500
        elif file_name[-5] == 'm':
            fmin, fmax = 80, 300
        else:
            fmin, fmax = 0, 0
        min = fmin
        max = fmax
        # Load audio data and sampling rate
        x, fs = librosa.load(file_path)
        x = x.astype(np.float32)
        hopsize = int(fs*0.005)

        # Deal with the situation with multi audio channels, just in case
        if x.ndim > 1:
            x = x[:,0]

        # Extract F0 using Swipe
        f0 = swipe(x, fs, min=fmin, max=fmax, hopsize=hopsize)
        # Add timeaxis due to the absence of time when using Swipe
        timeaxis = np.arange(0, len(f0)) * (1.0 / fs)*hopsize 

        # Create a DataFrame
        data = np.column_stack((timeaxis, f0))
        data[:, 1] = np.round(data[:, 1], 6)
        df = pd.DataFrame(data, columns=['Time (s)', 'Frequency (Hz)'])
        df.replace({0: ''}, inplace=True)

        # Save as a file with a specific naming convention
        output_file_name = f'Swipe_{file_name.replace(".wav", ".txt")}'
        output_path = os.path.join(output_dir, output_file_name)
        df.to_csv(output_path, sep='\t', index=False, float_format='%.6f')

        print(f"Processed {file_name} and saved as {output_file_name}")
