import os
import librosa
import numpy as np
import pandas as pd

audio_dir = '../recordings/'
output_dir = '../data/'
os.makedirs(output_dir, exist_ok=True)

# Iterate through each file in the audio directory
for file_name in os.listdir(audio_dir):
    if file_name.endswith('.wav'):
        # Get the full path of the audio file
        file_path = os.path.join(audio_dir, file_name)

        # Determine fmin and fmax based on the last letter of the file name
        last_letter = file_name[-5]  
        if last_letter == 'm':
            fmin, fmax = 80, 300
        elif last_letter == 'f':
            fmin, fmax = 140, 500
        else:
            fmin, fmax = 0, 0

        # Load audio data and sampling rate
        y, sr = librosa.load(file_path, sr=None)

        # Use pyin function to estimate fundamental frequency
        f0, _, _ = librosa.pyin(y, fmin=fmin, fmax=fmax, sr=sr)

        # Calculate time axis
        times = librosa.times_like(f0, sr=sr)

        # Create a DataFrame
        data = np.column_stack((times, f0))
        data[:, 1] = np.round(data[:, 1], 6)
        df = pd.DataFrame(data, columns=['Time (s)', 'Frequency (Hz)'])
        df.replace({np.nan: ''}, inplace=True)

        # Save as a file with a specific naming convention
        output_file_name = f'YIN_{file_name.replace(".wav", ".txt")}'
        output_path = os.path.join(output_dir, output_file_name)
        df.to_csv(output_path, sep='\t', index=False, float_format='%.6f')

        print(f"Processed {file_name} and saved as {output_file_name}")
