import pandas as pd
import numpy as np
import os
import matplotlib.pyplot as plt

# Define the directory for data files
data_dir = '../data'

# Define the directory for plot files
plot_dir = '../plot'
os.makedirs(plot_dir, exist_ok=True)

# Define the dictionary for category titles
category_titles = {
    'normal': 'Normal',
    'quiet': 'Quiet',
    'breathy': 'Breathy',
    'rainy': 'Rainy',
    'noisy': 'Noisy'
}

# Define the list of filenames
filenames = [
    'YIN_recording1_normal_fm.txt', 'Praat_recording1_normal_fm.txt', 'Swipe_recording1_normal_fm.txt',
    'YIN_recording2_quiet_fm.txt', 'Praat_recording2_quiet_fm.txt', 'Swipe_recording2_quiet_fm.txt',
    'YIN_recording3_breathy_m.txt', 'Praat_recording3_breathy_m.txt', 'Swipe_recording3_breathy_m.txt',
    'YIN_recording4_rainy_fm.txt', 'Praat_recording4_rainy_fm.txt', 'Swipe_recording4_rainy_fm.txt',
    'YIN_recording5_noisy_m.txt', 'Praat_recording5_noisy_m.txt', 'Swipe_recording5_noisy_m.txt'
]

def read_and_process_file(filename):
    data = pd.read_csv(filename, skiprows=1, header=None, sep="\t")
    x = data[0].to_numpy()
    y = data[1].apply(lambda val: float(val) if not pd.isna(val) else np.nan).to_numpy()
    return x, y

# Plot settings
plt.figure(figsize=(10, 5))
plt.xlabel('Time (s)')
plt.ylabel('Fundamental Frequency (Hz)')

# Process each file and plot
# Set colors, transparency, and marker sizes
line_styles = ['--', '-.', ':']
label_list = ['YIN', 'Praat', 'Swipe']
colors = [(0, 0, 1), (1, 0, 0), (0, 1, 0)]
offsets = [0, 5, 10]  # Offsets introduced here to make the overlapped lines clearer 

# Process each file and plot
for i, filename in enumerate(filenames):
    x, y = read_and_process_file(os.path.join(data_dir, filename))

    plt.plot(x, y + offsets[i % 3], linestyle=line_styles[i % 3], color=colors[i % 3], label=label_list[i % 3])

    if (i + 1) % 3 == 0:
        category = filename.split('_')[2]
        # Save the plot after processing each set of three files
        plot_filename = f"{filenames[i].split('_')[1]}_{category}_{filenames[i].split('_')[3].replace('.txt', '_pitch_plot.png')}"
        plt.legend()  # Show legend
        plt.title(f'Pitch Tracking Plot for {category_titles[category]} Speech')
        plt.savefig(os.path.join(plot_dir, plot_filename))
        plt.clf()  # Clear the plot for the next set

        # Create a new figure for the next iteration
        plt.figure(figsize=(10, 5))

# Show any remaining plot
if plt.gca().has_data():
    plt.legend()
    plt.show()
